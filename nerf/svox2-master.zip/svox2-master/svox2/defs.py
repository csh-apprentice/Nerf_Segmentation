# Basis types (copied from C++ data_spec.hpp)
BASIS_TYPE_SH = 1
BASIS_TYPE_3D_TEXTURE = 4
BASIS_TYPE_MLP = 255
